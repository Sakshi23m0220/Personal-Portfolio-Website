DROP DATABASE IF EXISTS portfolio_db;

CREATE DATABASE portfolio_db;
