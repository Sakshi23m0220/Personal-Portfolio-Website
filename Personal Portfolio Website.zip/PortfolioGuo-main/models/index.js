const Project = require('./Project');
const Contact = require('./Contact');

module.exports = { Project, Contact };